### Stack Overflow

The best place to ask for help with specific Telescope questions is [Stack Overflow](http://stackoverflow.com/questions/tagged/telescope). Just make sure you use the `telescope` tag!

### Telescope Meta

If you don't have a question, but instead want to discuss a specific aspect of Telescope (or show the world your new Telescope site!), feel free to open a topic on [Telescope Meta](http://meta.telesc.pe).

### GitHub Issues

Finally, if you've found a bug in Telescope, then you should [leave an issue on GitHub](https://github.com/TelescopeJS/Telescope/issues).