(function(){TAPi18n._enable({"helper_name":"_","supported_languages":null,"i18n_files_route":"/tap-i18n","cdn_path":null});
TAPi18n.languages_names["en"] = ["English","English"];

})();
